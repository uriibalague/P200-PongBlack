class Pala extends Rectangle{
    constructor(puntPosicio, amplada, alcada){
        super(puntPosicio, amplada, alcada);
        this.velocitatX = 2;
        this.velocitatY = 2;
         
        this.cocolorRectangle = "#eee";
    }

    mou(x,y){
        this.puntPosicio.x += x;
        this.puntPosicio.y += y;
    }
    update(key, alcada){
        if(key.DOWN.pressed){
         /********************************* 
         * Tasca. Definir el moviment de la pala
         * en funció de la tecla premuda
        **********************************/
       //this.puntPosicio.y += 5;
        if(this.puntPosicio.y + this.alcada < alcada){
            this.mou(0,this.velocitatY);
        }

        }
        if(key.UP.pressed){
       /********************************* 
         * Tasca. Definir el moviment de la pala
         * en funció de la tecla premuda
        **********************************/
        }
    }
    updateAuto(alcada){
        /********************************* 
         * Tasca. Definir el moviment de la pala
         * automàtica en moviment constant 
         * o amb variacions aleatories
        **********************************/

    }

}